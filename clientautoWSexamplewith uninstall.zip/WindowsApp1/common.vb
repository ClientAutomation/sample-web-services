﻿'make sure you open windowsApp1>properties>settings and change the value of WindowsApp1_clientauto_DSMWebServiceAPIService to point to the directory the mod_gsoap_utf8.dll is on your system
'this app logs to a file c:\PackageModifyApp.log you can change the name in the logcreate function on this page
'i have the values of host, user, domain and password prepopulated  you can change them or wait the gui will try and fail 
'you can then poulate new values that will be retained
'those values are just below

'I have created the app so each discrete type of action is one function so you can take the modules out and use them 

' basiclly the all when it starts tries to login with the predefined credentials  if it fails the gui will propmt for new credentials
'once credentials are correct the app will
'   get a list of all pacakges and display them in the top right of the screen
'   get a list of all the machnes and display them in the left middle of the screen
'   get a list of all the top level groups and display them in the middle of the screeen
'choose at least 1 group and at least 1 machine as a targets
'choose a software package
'   once you choose a package the app will display a list of procedures for the chosen package
'   make sure you choose an install job that is all i have coded for at the moment
'   currently i have not coded for any advanced option such as setting time, user parameters, reboot options, etc
'choose the procedure
'you will now see a box to enter the container name
'   enter a name
'select create container
'thats it the job is built and runnning


'you will get messagebox popups if there are errors any of the web calls


'limitations

'by no means is this app hardened i trap for webservice failurs and log most actions 
'but any other unforseen coding errors the app will choke

'at the moment ther is nothing in the app to allow you to choose another package once you create the container
'you must exit and start again  until you hit create you can backup and choose different targets or a different package
'
'currently you MUST include at least one group as a target it can be an empty group.  you can target 0 to many individual machines
'   so lets say you want to deploy to 1 machine pick the one from the machine list and an empty group
'   that same issue does not exist for groups you can select 1 group and no individual machines it works fine

'I am trying to figure out how to thell the app tat the mod_gsoap file is compiled into the app itself
'I tried off and on to create an installer that will put the file somewhere



'near future changes
'add a button to "do another" in other words it will leave all the buffers full except the ones that include what was chosen
'add a sequence to display status of the container and the job





Imports System
Imports System.IO
Imports System.Net
Imports System.String
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data.SqlClient
Imports System.Runtime.InteropServices '   DllImport
Imports System.Security.Principal '  WindowsImpersonationContext
Imports System.Security.Permissions
Imports System.Text



Module common

    Public FinalStat As String = ""
    Public CurVal(1) As String 'used to pass extra values out of backgroundworker2
    Public Host As String = "lecri01-129dm" 'entered on startup screen or saved in settings
    Public UserENC As String 'created in WSlogin
    Public User As String = "Administrator" 'entered on startup screen or save in settings
    Public Domain As String = "lecri01-129dm" ''entered on startup screen or save in settings
    Public Password As String = "CAdemo123" 'entered on startup screen or save in settings
    Public PasswordENC As String 'created in WSlogin
    Public CredValidated As Boolean 'set in sartup.emvalidate if credentials are good
    Public FirstPass As Integer = 0 ' used to see if this is the first time the app has run on this session it sets things like mapped drives
    Public dsms As New WindowsApp1.clientauto.DSMWebServiceAPIService
    Public SessionID As New Object 'web service session ID
    Public SessionIDset As Boolean = False 'used to determine if WSlogoff is needed at exit
    Public TotalPackageCount As Long 'Total number of sd packages registered 
    Public TotalMachineCount As Long
    Public TotalGroupCount As Long
    Public TotalInstallProcedureCount As Long
    Public TotalUninstallProcedureCount As Long
    Public PackageNameList(10000) As String 'package names
    Public PackageVersionList(10000) As String 'package versions
    Public PackageUUIDList(10000) As String 'package uuids
    Public Suggestions(10000) As String 'concantinated package name and version for display in gui
    Public ComputerNameList(20000) As String
    Public ComputerUUIDList(20000) As String
    Public GroupNameList(5000) As String
    Public GroupUUIDList(5000) As String
    Public InstallProcedureNameList(50) As String
    Public InstallProcedureUUIDList(50) As String
    Public UninstallProcedureNameList(50) As String
    Public UninstallProcedureUUIDList(50) As String
    Public SelectedPackageName As String
    Public SelectedPackageVersion As String
    Public SelectedPackageUUID As String
    Public SelectedInstallProcedureName As String
    Public SelectedInstallProcedureUUID As String
    Public SelectedUnInstallProcedureName As String
    Public SelectedUnInstallProcedureUUID As String

    Public MyHostName As String = My.Computer.Name 'used to determine if this app is running on an em or dm to determine where to log and map drives
    Public ContainerUUID
    Public IsLocal As Boolean
    Public MachineArray() As String
    Public GroupArray() As String
    Public SoftwarePackageInstallProcedureID As String

    Public SelectedPackageversionTmp As String
    Public SelectedPackageNameTmp As String

    Public Uselocal As Boolean 'tells logins to assume credentials are local not domain so sets user as hostname\user instade of emdomain\user



    Function WSLogin(HostName As String) As String 'called by startup.validate to see if credentials are valid
        Dim tmpuser As String
        UpdateLog(1, "common.WSlogin", "Attemping to get sessionID from " + HostName, 0)
        SessionID = ""
        If Uselocal = True Then
            tmpuser = HostName + "/" + User
        Else
            tmpuser = Domain + "/" + User
        End If
        Try
            dsms.Url = "http://" + HostName + "/DSM_Webservice/mod_gsoap.dll"
            PasswordENC = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes(Password))
            UserENC = Convert.ToBase64String(New System.Text.ASCIIEncoding().GetBytes("winnt://" + tmpuser))
            UpdateLog(1, "common.WSlogin", "Trying To login To WebServices On Server " + HostName + " as user " + tmpuser, 0)
            SessionID = dsms.Login2(UserENC, PasswordENC, HostName)
        Catch ex As Exception
            MessageBox.Show("Trying To login To WebServices On Server " + HostName + vbCrLf + "as user " + tmpuser + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            UpdateLog(1, "common.WSlogin", "Trying To login To WebServices On Server " + HostName + "as user " + tmpuser + "Process returned the following error" + ex.Message, 2)
            Return "NOTOK"

        End Try
        UpdateLog(1, "common.WSlogin", "Obtained sessionid " + SessionID.ToString, 0)

        Return "OK"
    End Function

    Function WSLogout() As String  'called when exit button is hit

        UpdateLog(1, "common.logout", "Attemping to release sessionID from " + Host, 0)

        If SessionIDset = True Then
            Try
                dsms.Logout(SessionID.ToString)
            Catch ex As Exception
                UpdateLog(1, "common.logout", "Failed to release sessionID from " + Host, 1)
                Return "NOTOK"
            End Try
            UpdateLog(1, "common.logout", "SessionID Released ", 0)
            SessionIDset = False
        End If
        Return "OK"
    End Function
    Function WSGetAllSoftware() As String  'called by startup.validate once credentials have been validate 
        UpdateLog(1, "common.GetAllSoftware", "Attemping Get total number of software packages registered on " + Host, 0)
        Dim WSoutSoftwarePackageList() As clientauto.SoftwarePackageProperties2
        Dim ReturnText As String = Nothing
        Dim Failed As Boolean = False
        Dim index As Long = 0
        Dim numrequired As Long
        Dim SoftwarePackageGroupID As String = Nothing 'if groupuuid is specified then the search will only get packages from that group if set to nothing it will get all packages (NOTE nothing is not the same as "")
        Dim TotalCount As Long = Nothing
        Dim j As Integer
        Dim packpropreq As New clientauto.SoftwarePackagePropertiesRequired With {
        .softwarePackageNameRequired = True,
        .softwarePackageVersionRequired = True,
        .softwarePackageIdRequired = True}

        Dim sortprop As clientauto.SoftwarePackageProperty = clientauto.SoftwarePackageProperty.SDPKGNAME

        Dim packfilter(0) As clientauto.SoftwarePackageFilter
        packfilter(0) = New clientauto.SoftwarePackageFilter() With {
        .swPkgProperty = clientauto.SoftwarePackageProperty.SDPKGNAME,
        .condition = clientauto.FILTERCONDITION.FILTERWILDCARDEQ,
        .searchString = "*"}

        Dim ArrayOfSoftwarePackageFilter As clientauto.ArrayOfSoftwarePackageFilter = New clientauto.ArrayOfSoftwarePackageFilter With {
        .filter = packfilter,
        .matchAll = True}
        Try
            WSoutSoftwarePackageList = dsms.GetSoftwarePackageList(SessionID.ToString, SoftwarePackageGroupID, packpropreq, ArrayOfSoftwarePackageFilter, clientauto.SoftwarePackageProperty.SDPKGBASEDONPKGNAME, True, index, numrequired, True, TotalCount)
        Catch ex As Exception
            UpdateLog(1, "common.GetAllSoftware", "Trying to Get total number of software packages registered returned the following error" + ex.Message, 0)
            MessageBox.Show("Trying to Get Total number of software packages" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try
        If TotalCount = 0 Then
            UpdateLog(1, "common.GetAllSoftware", "There are " + Str(TotalCount) + " registered packages on EM " + Host, 2)
            MessageBox.Show("There are no software packages")
            Return "NOTOK"
            Exit Function
        End If
        numrequired = TotalCount

        UpdateLog(1, "common.GetAllSoftware", "There are " + Str(TotalCount) + " registered packages on " + Host, 0)
        UpdateLog(1, "common.GetAllSoftware", "Trying to Get list of  all software packages on  " + Host, 0)

        If TotalCount = 0 Then
            MessageBox.Show("There are no software packages")
            Return "NOTOK"
            Exit Function
        End If

        Try
            WSoutSoftwarePackageList = dsms.GetSoftwarePackageList(SessionID.ToString, SoftwarePackageGroupID, packpropreq, ArrayOfSoftwarePackageFilter, clientauto.SoftwarePackageProperty.SDPKGBASEDONPKGNAME, True, index, numrequired, True, TotalCount)

        Catch ex As Exception
            UpdateLog(1, "common.GetAllSoftware", "Trying to Get total number of software packages registered returned the following error" + ex.Message, 0)
            MessageBox.Show("Trying to Get Total number of software packages" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try

        TotalPackageCount = TotalCount - 1
        For j = 0 To TotalPackageCount
            PackageNameList(j) = WSoutSoftwarePackageList(j).softwarePackageName
            PackageVersionList(j) = WSoutSoftwarePackageList(j).softwarePackageVersion
            Suggestions(j) = PackageNameList(j) + "'" + PackageVersionList(j)
            PackageUUIDList(j) = WSoutSoftwarePackageList(j).softwarePackageId
        Next
        UpdateLog(1, "common.GetAllSoftware", "Get list of  all software packages completed " + Host, 0)
        Return "OK"
    End Function

    Function WSGetAllComputers() As String 'called by startup.validate after wsgetallsoftware completes
        UpdateLog(1, "common.GetAllComputers", "Attemping Get total $AllComputer UUID", 0)
        Dim ret As String = WSGetAllComputerUUID()
        Dim Allcomputers() As clientauto.ComputerProperties2
        UpdateLog(1, "common.GetAllComputers", "Attemping Get total number of computers registered on " + Host, 0)
        TotalMachineCount = 0
        Dim ss As String = "*"
        Dim ComputerProperty2 As New clientauto.ComputerProperty2
        ComputerProperty2 = clientauto.ComputerProperty2.COMPUTERHOSTNAME


        Dim ComputerPropertyFilter2(0) As clientauto.ComputerPropertyFilter2
        ComputerPropertyFilter2(0) = New clientauto.ComputerPropertyFilter2() With {
        .searchString = "*",
        .computerProperty = clientauto.ComputerProperty2.COMPUTERHOSTNAME,
        .filterCondition = clientauto.ComputerFilterCondition.COMPUTERFILTERWILDCARDEQ}


        Dim handle As Long
        Dim ComputerPropertiesRequired2 As New clientauto.ComputerPropertiesRequired2 With {
        .computerHostNameRequired = True,
        .computerHostUUIDRequired = True}
        Dim TotalSpecified As Boolean = True
        Try
            dsms.OpenUnitGroupComputerMembersList2(SessionID.ToString, ret, ComputerPropertyFilter2, True, ComputerProperty2, handle, ComputerPropertiesRequired2, handle, True, TotalMachineCount, TotalSpecified)
        Catch ex As Exception
            UpdateLog(1, "common.GetAllComputers", "Trying to Get total number of  computer registered returned the following error" + ex.Message, 0)
            MessageBox.Show("Trying to Get Total number of computers" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try

        UpdateLog(1, "common.GetAllComputers", "Total number of computers registered on " + Host + "is " + Str(TotalMachineCount), 0)
        Try
            Allcomputers = dsms.GetUnitGroupComputerMembers2(SessionID.ToString, handle, TotalMachineCount)
            dsms.CloseUnitGroupComputerMembersList(SessionID.ToString, handle)
        Catch ex As Exception
            UpdateLog(1, "common.GetAllComputers", "Trying to list of  computers registered returned the following error" + ex.Message, 0)
            MessageBox.Show("Trying to Get list of computers" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try
        TotalMachineCount = TotalMachineCount - 1
        For j = 0 To TotalMachineCount
            ComputerNameList(j) = Allcomputers(j).computerHostName
            ComputerUUIDList(j) = Allcomputers(j).computerHostUUID

        Next
        UpdateLog(1, "common.GetAllComputers", "Get list of  all computers completed " + Host, 0)
        Return "OK"



    End Function

    Function WSGetAllGroups() As String 'gets all the groups at the top level it does not recurse the groups called by startup.validate afre wsgetallcomputers completes
        Dim rtn As String = WSGetAllGroupUUID()
        Dim UnitGroupPropertiesRequired As New clientauto.UnitGroupPropertiesRequired
        Dim Handle As Long
        UnitGroupPropertiesRequired.groupUUIDRequired = True
        UnitGroupPropertiesRequired.groupLabelRequired = True
        TotalGroupCount = 0
        UpdateLog(1, "common.WSGetAllGroups", "Attemping Get total number of groups registered on " + Host, 0)
        Dim allgroups() As clientauto.UnitGroupProperties
        Try
            dsms.OpenUnitGroupUnitGroupMembersList(SessionID.ToString, rtn, UnitGroupPropertiesRequired, Handle, True, TotalGroupCount, True)

        Catch ex As Exception
            UpdateLog(1, "common.WSGetAllGroups", "Trying to Get total number of  groups registered returned the following error" + ex.Message, 0)
            MessageBox.Show("Trying to Get Total number of groups" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try
        UpdateLog(1, "common.GetAllComputers", "Total number of groups on " + Host + "is " + Str(TotalGroupCount), 0)
        Try
            allgroups = dsms.GetUnitGroupUnitGroupMembers(SessionID.ToString, Handle, TotalGroupCount)
            dsms.CloseUnitGroupUnitGroupMembersList(SessionID.ToString, Handle)
        Catch ex As Exception
            UpdateLog(1, "common.WSGetAllGroups", "Trying to Get list of  groups registered returned the following error" + ex.Message, 0)
            MessageBox.Show("Trying to Get list of groups" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try
        TotalGroupCount = TotalGroupCount - 1
        For j = 0 To TotalGroupCount
            GroupNameList(j) = allgroups(j).groupLabel
            GroupUUIDList(j) = allgroups(j).groupUUID
        Next
        UpdateLog(1, "common.GetAllGroups", "Get list of  all groups completed " + Host, 0)

        Return "OK"
    End Function

    Function WSGetInstallPackageProceures() As String 'called once one has selected a pacakge from the softwareselect pull down 
        Dim index As Long
        Dim NumReq As Long

        Dim SoftwarePackageProcedureProperties4() As clientauto.SoftwarePackageProcedureProperties4

        Dim SoftwarePackageProceduretypeMask As New clientauto.SoftwarePackageProcedureTypeMask With {
        .install = True
        }


        Dim SoftwarePackageProceduresRequred2 As New clientauto.SoftwarePackageProcedurePropertiesRequired2 With {
        .softwarePackageProcedureIdRequired = True,
        .softwarePackageProcedureNameRequired = True
        }
        Try
            SoftwarePackageProcedureProperties4 = dsms.GetSoftwarePackageProcedureList(SessionID.ToString, SelectedPackageUUID, SoftwarePackageProceduretypeMask, SoftwarePackageProceduresRequred2, index, NumReq, TotalInstallProcedureCount)

        Catch ex As Exception
            UpdateLog(1, "common.WSGetInstallPackageProcedures", "Trying to Get list of  procedures for the selected software package returned the following error" + ex.Message, 0)
            MessageBox.Show("Trying to Get list Install of procedures" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try
        UpdateLog(1, "common.WSGetInstallPackageProcedures", "Get list of  procedures completed " + Host, 0)

        NumReq = TotalInstallProcedureCount

        Try
            SoftwarePackageProcedureProperties4 = dsms.GetSoftwarePackageProcedureList(SessionID.ToString, SelectedPackageUUID, SoftwarePackageProceduretypeMask, SoftwarePackageProceduresRequred2, index, NumReq, TotalInstallProcedureCount)

        Catch ex As Exception
            UpdateLog(1, "common.WSInstallGetPackageProcedures", "Trying to Get list of  procedures for the selected software package returned the following error" + ex.Message, 0)
            MessageBox.Show("Trying to Get list of install procedures" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try




        For j = 0 To TotalInstallProcedureCount - 1
            InstallProcedureNameList(j) = SoftwarePackageProcedureProperties4(j).softwarePackageProcedureName
            InstallProcedureUUIDList(j) = SoftwarePackageProcedureProperties4(j).softwarePackageProcedureId
        Next
        Return "OK"


    End Function

    Function WSGetUnInstallPackageProceures() As String 'called once one has selected a pacakge from the softwareselect pull down 
        Dim index As Long
        Dim NumReq As Long

        Dim SoftwarePackageProcedureProperties4() As clientauto.SoftwarePackageProcedureProperties4

        Dim SoftwarePackageProceduretypeMask As New clientauto.SoftwarePackageProcedureTypeMask With {
        .uninstall = True
        }


        Dim SoftwarePackageProceduresRequred2 As New clientauto.SoftwarePackageProcedurePropertiesRequired2 With {
        .softwarePackageProcedureIdRequired = True,
        .softwarePackageProcedureNameRequired = True
        }
        Try
            SoftwarePackageProcedureProperties4 = dsms.GetSoftwarePackageProcedureList(SessionID.ToString, SelectedPackageUUID, SoftwarePackageProceduretypeMask, SoftwarePackageProceduresRequred2, index, NumReq, TotalUnInstallProcedureCount)

        Catch ex As Exception
            UpdateLog(1, "common.WSGetUnistallPackageProcedures", "Trying to Get list of  procedures for the selected software package returned the following error" + ex.Message, 0)
            MessageBox.Show("Trying to Get list of Unistall procedures" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try
        UpdateLog(1, "common.GetUnistallPackageProcedures", "Get list of  procedures completed " + Host, 0)

        NumReq = TotalUninstallProcedureCount

        Try
            SoftwarePackageProcedureProperties4 = dsms.GetSoftwarePackageProcedureList(SessionID.ToString, SelectedPackageUUID, SoftwarePackageProceduretypeMask, SoftwarePackageProceduresRequred2, index, NumReq, TotalUninstallProcedureCount)

        Catch ex As Exception
            UpdateLog(1, "common.WSGetUnistallPackageProcedures", "Trying to Get list of  procedures for the selected software package returned the following error" + ex.Message, 0)
            MessageBox.Show("Trying to Get list of Uninstall procedures" + vbCrLf + "Process returned the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try




        For j = 0 To TotalUnInstallProcedureCount - 1
            UninstallProcedureNameList(j) = SoftwarePackageProcedureProperties4(j).softwarePackageProcedureName
            UninstallProcedureUUIDList(j) = SoftwarePackageProcedureProperties4(j).softwarePackageProcedureId
        Next
        Return "OK"

    End Function



    Function WSCreateContainer(ContainerName As String) As String 'called by button create container once a procedure and targets are selected 

        Dim SoftwareJobContainerProperties As clientauto.CreateSoftwareJobContainerProperties = New clientauto.CreateSoftwareJobContainerProperties With {
       .name = ContainerName,
       .nameSupplied = True}

        Try
            ContainerUUID = dsms.CreateSoftwareJobContainer(SessionID.ToString, SoftwareJobContainerProperties)
        Catch ex As Exception

            UpdateLog(1, "common.wsCreateContainer", "Create Software job Container Process generated the following error", 2)
            UpdateLog(1, "common.WsDeliverSoftware", ex.Message, 2)
            MessageBox.Show("process WSCreateContainer Creating software job container generated the following error" + vbCrLf + ex.Message)
            Return "NOTOK"


        End Try
        UpdateLog(1, "common.WScreateContainer", "Created SD job delivery container " + ContainerName + " containerUUID=" + ContainerUUID, 0)

        Return "OK"
    End Function

    Function WSCreateInstallSoftwareJob(SDJobName As String) As String  'called by create container button assuming WScreate container completes
        Dim CreateSoftwareJobOrderProperties As clientauto.CreateSoftwareJobOrderProperties = New clientauto.CreateSoftwareJobOrderProperties With {
        .jobName = SDJobName,
        .jobNameSupplied = True}
        Dim JobID As String
        Try
            JobID = dsms.CreateInstallSoftwareJob(SessionID.ToString, SelectedInstallProcedureUUID, CreateSoftwareJobOrderProperties, ContainerUUID, GroupArray, MachineArray)
        Catch ex As Exception
            UpdateLog(1, "common.wsCreateSoftwareJob", "Create Install Software job  Process generated the following error", 2)
            UpdateLog(1, "common.WsCreateSoftwareJob", ex.Message, 2)
            MessageBox.Show("process WSCreateSoftware Creating Install software job generated the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
        End Try
        UpdateLog(1, "common.WSCreateSoftwareJob", "Software job added jobID= " + JobID, 0)
        Return JobID
    End Function
    Function WSSealAndActivate() As String  'called by create container once wscreatedsoftware job completes 


        UpdateLog(1, "common.WSSoftware", "Preparing to seal and activate the container", 0)

        Try
            dsms.SealAndActivateSoftwareJobContainer(SessionID.ToString, ContainerUUID)
        Catch ex As Exception
            UpdateLog(1, "common.SealAndActivate", "SealAndActivateJobContainer process generated the following error", 2)
            UpdateLog(1, "common.SealAndActivate", ex.Message, 2)
            MessageBox.Show("process SealAndActivateContainer process generated the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
        End Try

        UpdateLog(1, "common.SealAndActivate", "Software job sealed and activated", 0)
        Return "OK"


    End Function

    Function WSCreateUninstallSoftwareJob(SDJobName As String) As String
        Dim CreateSoftwareJobOrderProperties As clientauto.CreateSoftwareJobOrderProperties = New clientauto.CreateSoftwareJobOrderProperties With {
        .jobName = SDJobName,
        .jobNameSupplied = True}
        Dim JobID As String
        Dim AllComputerUUID As String
        Dim unitsoftwarejobpropertiesrequired As clientauto.UnitSoftwareJobPropertiesRequired = New clientauto.UnitSoftwareJobPropertiesRequired With {
            .softwareJobIdRequired = True,
        .unitHostUUIDRequired = True,
        .softwarePackageProcedureIdRequired = True,
        .unitInstallationSoftwareJobIdRequired = True}
        Dim handle As Long
        Dim totalpackagecount As Long
        Dim unitsoftwareproperties() As clientauto.UnitSoftwareJobProperties
        Dim installjobid(100) As String
        AllComputerUUID = WSGetAllComputerUUID()
        Try
            dsms.OpenSoftwarePackageInstallationList(SessionID.ToString, SelectedPackageUUID, AllComputerUUID, unitsoftwarejobpropertiesrequired, handle, True, totalpackagecount, True)
            UpdateLog(1, "common.CreateUnistallSoftwareJob", "Getsoftwarepackageinstallations after open", 2)
            UpdateLog(1, "common.CreateUnistallSoftwareJob", "Getsoftwarepackageinstallations handle=" + Str(handle) + ", totalpackagecount=" + Str(totalpackagecount), 2)
            unitsoftwareproperties = dsms.GetSoftwarePackageInstallations(SessionID.ToString, handle, totalpackagecount)
            UpdateLog(1, "common.CreateUnistallSoftwareJob", "Getsoftwarepackageinstallations after get", 2)

            dsms.CloseSoftwarePackageInstallationList(SessionID.ToString, handle)
            UpdateLog(1, "common.CreateUnistallSoftwareJob", "Getsoftwarepackageinstallations after close", 2)
            MessageBox.Show(unitsoftwareproperties(0).unitInstallationSoftwareJobId)
            MessageBox.Show(unitsoftwareproperties(0).softwareJobId)
        Catch ex As Exception
            UpdateLog(1, "common.CreateUnistallSoftwareJob", "Getsoftwarepackageinstallations Process generated the following error", 2)
            UpdateLog(1, "common.CreateUninstallSoftwareJob", ex.Message, 2)
            MessageBox.Show("process CreateUnistallSoftwareJob/Getsoftwarepackageinstallation generated the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
            Exit Function
        End Try
        For j = 0 To totalpackagecount - 1
            installjobid(j) = unitsoftwareproperties(j).softwareJobId
        Next
        UpdateLog(1, "common.CreateUnistallSoftwareJob", "after j loop", 2)
        Dim installjobid1() As String


        Try
            JobID = dsms.CreateUninstallSoftwareJob(SessionID.ToString, SelectedUnInstallProcedureUUID, SelectedInstallProcedureUUID, CreateSoftwareJobOrderProperties, ContainerUUID, installjobid1, GroupArray, MachineArray)

        Catch ex As Exception
            UpdateLog(1, "common.CreateUnistallSoftwareJob", "Process generated the following error", 2)
            UpdateLog(1, "common.CreateUninstallSoftwareJob", ex.Message, 2)
            MessageBox.Show("process CreateUnistallSoftwareJobG generated the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
        End Try
        Return "OK"
    End Function
    Function WSGetAllComputerUUID() As String 'called by wsGetAllComputer to get the uuid of the all computer group
        Dim SG As clientauto.SystemGroup = clientauto.SystemGroup.COALLCOMPUTERS


        Dim Rtn As String
        Try
            Rtn = dsms.GetSystemGroupUUID(SessionID.ToString, SG)
        Catch ex As Exception
            UpdateLog(1, "common.wsGetAllComputerUUID", "Process generated the following error", 2)
            UpdateLog(1, "common.WsGetAllComputerUUID", ex.Message, 2)
            MessageBox.Show("process WSGetAllComputerUUID generated the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
        End Try
        UpdateLog(1, "common.WsGetAllComputerUUID", "$ALLCOMPUTERS UUID=" + Rtn, 0)
        Return Rtn

    End Function

    Function WSGetAllGroupUUID() As String 'called by wsgetallgroups to get the uud of the allComputerAndUsersGroup
        Dim SG As clientauto.SystemGroup = clientauto.SystemGroup.COALLCOMPUTERSUSERSGROUP
        Dim Rtn As String
        Try
            Rtn = dsms.GetSystemGroupUUID(SessionID.ToString, SG)
        Catch ex As Exception
            UpdateLog(1, "common.wsGetAllGroupUUID", "Process generated the following error", 2)
            UpdateLog(1, "common.WsGetAllGroupUUID", ex.Message, 2)
            MessageBox.Show("process GetAllGroupUUID generated the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
        End Try
        UpdateLog(1, "common.WsGetGroupUUID", "$ALLComputerUsers UUID=" + Rtn, 0)
        Return Rtn
    End Function




    Public Sub Exitapp()
        If SessionIDset = True Then
            WSLogout()


        End If


        Application.Exit()

    End Sub



    Function LogCreate(lognum As Integer) As String
        Dim logname As String
        If lognum = 1 Then
            logname = "c:\PackageModifyApp.log"

            'logname = MyDrive + "\PackageModifyApp\" + EMUser + "\logs\debug.log"

        Else
            logname = "C:\packageModifyPreMap.log"
        End If

        Try

            Using log As StreamWriter = File.CreateText(logname)
                log.WriteLine("Logging Begins")
                log.WriteLine("{0,-18}{1,-30}{2,-90}", "Severity", "Calling Module", "Message")
            End Using
        Catch ex As Exception
            MessageBox.Show("unable to create log file " + logname)
            Return "NOTOK"
        End Try
        Return "OK"
    End Function
    Function UpdateLog(lognum As Integer, CallingModule As String, Ts As String, Severity As Integer) As String
        Dim logname As String
        If lognum = 1 Then
            logname = "c:\PackageModifyApp.log"
            'logname = MyDrive + "\PackageModifyApp\" + EMUser + "\logs\debug.log"

        Else
            logname = "C:\PackageModifyPreMap.log"
        End If

        Try

            Using log As StreamWriter = File.AppendText(logname)
                If Severity = 2 Then
                    log.WriteLine("{0,-18}{1,-30}{2,-90}", "***FATAL***", CallingModule, Ts)
                ElseIf Severity = 1 Then
                    log.WriteLine("{0,-18}{1,-30}{2,-90}", " Warning", CallingModule, Ts)
                Else
                    log.WriteLine("{0,-18}{1,-30}{2,-90}", "", CallingModule, Ts)
                End If
            End Using
        Catch ex As Exception
            MessageBox.Show("unable to update log file " + logname)
            Return "NOTOK"
        End Try
        Return "OK"
    End Function
    'extra functions not used by this app at this time
    Public Function DateCalculator(ByRef year As Integer, ByRef month As Integer, ByRef day As Integer, ByRef hour As Integer, ByRef minute As Integer, ByRef second As Integer, add As String, howlong As Integer, ByRef fyear As Integer, ByRef fmonth As Integer, ByRef fday As Integer, ByRef fhour As Integer, ByRef fminute As Integer, ByRef fsecond As Integer) As String
        Dim today As System.DateTime = System.DateTime.Now
        hour = today.Hour
        minute = today.Minute
        second = today.Second
        month = today.Month
        day = today.Day
        year = today.Year

        Dim future As System.DateTime
        Select Case add
            Case "min"
                future = today.AddMinutes(howlong)
            Case "hour"
                future = today.AddHours(howlong)
            Case "day"
                future = today.AddDays(howlong)

        End Select


        fhour = future.Hour
        fminute = future.Minute
        fsecond = future.Second
        fmonth = future.Month
        fday = future.Day
        fyear = future.Year
        Return "OK"
    End Function


    'finds computer by name

    Function WSFindComputer(Name As String) As String
        Dim CPR As clientauto.ComputerPropertiesRequired = New clientauto.ComputerPropertiesRequired With {
        .computerHostNameRequired = True,
        .computerHostUUIDRequired = True}
        Dim TmpCount As Long = 1
        Dim Count As Long
        Dim CP() As clientauto.ComputerProperties
        Try
            CP = dsms.FindComputer(SessionID.ToString, Name, TmpCount, CPR, Count, True)
        Catch ex As Exception
            UpdateLog(1, "common.wsFindComputer", "Process generated the following error", 2)
            UpdateLog(1, "common.WsFindComputer", ex.Message, 2)
            MessageBox.Show("process WSFindComputer generated the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
        End Try
        Dim J As Integer
        For J = 0 To Count
            If CP(J).computerHostName = Name Then
                UpdateLog(1, "common.WsFindComputer", "UUID for " + Name + " = " + CP(J).computerHostUUID, 2)
                Return CP(J).computerHostUUID
                Exit Function
            End If
        Next

        UpdateLog(1, "common.WsFindComputer", "Could Not Find the UUID for " + Name, 2)
        MessageBox.Show("process WSFindComputer Could Not Find the UUID for " + Name)
        Return "NOTOK"
    End Function
    'finds software procedure
    Function WSFindSDprocedure(PN As String, PV As String, ProcName As String) As String
        Dim SPPT As clientauto.SoftwarePackageProcedureTask = clientauto.SoftwarePackageProcedureTask.INSTALL
        Dim Rtn As String
        Try
            Rtn = dsms.FindSoftwarePackageProcedure(SessionID.ToString, PN, PV, ProcName, SPPT)
        Catch ex As Exception
            UpdateLog(1, "common.wsFindSDProcedure", "Process generated the following error", 2)
            UpdateLog(1, "common.WsFindSDProcedure", ex.Message, 2)
            MessageBox.Show("process WSFindSDProcedure generated the following error" + vbCrLf + ex.Message)
            Return "NOTOK"
        End Try
        UpdateLog(1, "common.wsFindSDProcedure", ProcName + " UUID=" + Rtn, 0)

        Return Rtn
    End Function

    Function MakeCADSMCMDCred(HostName As String) As String
        If Uselocal = True Then
            Return HostName
        Else
            Return Domain
        End If

    End Function





End Module