﻿Imports System.ComponentModel
Imports System.Configuration.Install
Imports System
Imports System.Diagnostics
Imports System.Windows.Forms
Imports System.Collections
Imports System.Reflection
Imports System.IO
Imports System.Configuration


Public Class Installer
    Inherits System.Configuration.Install.Installer
    Public Sub New()
        MyBase.New()
        AddHandler AfterInstall, AddressOf AfterInstallEventHandler
        'This call is required by the Component Designer.
        InitializeComponent()

        'Add initialization code after the call to InitializeComponent

    End Sub
    Private Sub AfterInstallEventHandler(ByVal sender As Object, ByVal e As InstallEventArgs)
        Dim AssemblyPath As String = Context.Parameters("assemblypath")

        Dim directoryname As String = Path.GetDirectoryName(AssemblyPath)

        Try
            Dim config As System.Configuration.Configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None)
            Dim Settings = config.AppSettings.Settings
            Dim key As String = "WindowsApp1_clientauto_DSMWebServiceAPIService"
            Dim value As String = directoryname + "\mod_gsoap_utf8.dll"







            MessageBox.Show("before")


            Settings(key).Value = value
            MessageBox.Show("here after")
            config.Save(ConfigurationSaveMode.Modified)
            ConfigurationManager.RefreshSection(config.AppSettings.SectionInformation.Name)
            MessageBox.Show("here good")
        Catch
            MessageBox.Show("here2 bad")
        End Try

    End Sub

    Public Overloads Overrides Sub Install(ByVal savedState As IDictionary)
        MyBase.Install(savedState)

    End Sub

    ' Override the 'Commit' method.
    Public Overloads Overrides Sub Commit(ByVal savedState As IDictionary)
        MyBase.Commit(savedState)




    End Sub
End Class
