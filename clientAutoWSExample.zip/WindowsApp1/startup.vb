﻿Imports System.ComponentModel
Imports System.Drawing.Color
Imports System.Drawing
Imports System.IO
Public Class Startup




    Private Sub Startup_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        LogCreate(0)
        If FirstPass = 1 Then

            If My.Settings.CAhost <> vbNullString Then
                Host = My.Settings.CAhost
            End If
            If My.Settings.CAdomain <> vbNullString Then
                Domain = My.Settings.CAdomain
            End If
            If My.Settings.CAuser <> vbNullString Then
                User = My.Settings.CAuser
            End If
            If My.Settings.CApassword <> vbNullString Then
                User = My.Settings.CAuser
            End If

            If My.Settings.UseLocal = "True" Then
                Uselocal = True
                CheckBoxLocal.Checked = True
            Else
                Uselocal = False
                CheckBoxLocal.Checked = False
            End If
        End If
        If Host <> vbNullString And User <> vbNullString And Password <> vbNullString And Domain <> vbNullString Then
            UpdateLog(0, "startup.startup_load", "credentials are prepopulated testing them now", 0)
            TBHost.Text = Host
            tbdomain.Text = Domain
            tbemuser.Text = User
            tbpassword.Text = Password
            ManagerValidate()
        End If
        FirstPass = 1



    End Sub

    Private Sub TBEMHost_TextChanged(sender As Object, e As EventArgs) Handles TBHost.TextChanged
        Host = TBHost.Text
        CheckForValidation()
    End Sub
    Private Sub TbEMdomain_TextChanged(sender As Object, e As EventArgs) Handles tbdomain.TextChanged
        Domain = tbdomain.Text
        CheckForValidation()
    End Sub

    Private Sub TBEMUser_TextChanged(sender As Object, e As EventArgs) Handles tbemuser.TextChanged
        User = tbemuser.Text
        CheckForValidation()
    End Sub

    Private Sub TBEMPassword_TextChanged(sender As Object, e As EventArgs) Handles tbpassword.TextChanged
        Password = tbpassword.Text
        CheckForValidation()
    End Sub

    Private Sub CheckForValidation()
        CredValidated = False
        Bukeep.Visible = False
        If Host <> vbNullString And User <> vbNullString And Password <> vbNullString And Domain <> vbNullString Then
            LBCAvalidation.Text = "Client Auto Credentials need validating"
            BUValidate.Visible = True
        Else
            LBCAvalidation.Text = "All 4 fields must be populated"
            BUValidate.Visible = False
        End If

    End Sub

    Private Sub ManagerValidate()
        Dim rtn As String
        Dim am As Integer = 1

        LBAllSoftware.Visible = False
        LBAllSoftware.Text = "Getting List of software packages"
        If SessionIDset = True Then
            rtn = UpdateLog(am, "startup.validate", "Existing web services session exists will log off", 0)
            rtn = WSLogout()
            If rtn = "OK" Then
                SessionIDset = False
                rtn = UpdateLog(am, "startup.validate", "log off OK", 0)
            Else
                rtn = UpdateLog(am, "startup.validate", "log off failed", 2)

            End If

        End If
        rtn = UpdateLog(am, "startup.validate", "Clearing all arrays", 0)
        If CBAllSoftware.Items.Count > 0 Then
            CBAllSoftware.Items.Clear()
            TotalPackageCount = 0
            PackageNameList.Initialize()
            PackageUUIDList.Initialize()
            PackageVersionList.Initialize()
            Suggestions.Initialize()

        End If

        If ListBoxMachine.Items.Count > 0 Then
            ListBoxMachine.Items.Clear()
            TotalMachineCount = 0
            ComputerNameList.Initialize()
            ComputerUUIDList.Initialize()

        End If

        If ListBoxGroup.Items.Count > 0 Then
            ListBoxGroup.Items.Clear()
            TotalGroupCount = 0
            GroupNameList.Initialize()
            GroupUUIDList.Initialize()
        End If

        If CBProcedure.Items.Count > 0 Then
            TotalProcedureCount = 0
            CBProcedure.Items.Clear()
            ProcedureNameList.Initialize()
            ProcedureUUIDList.Initialize()
        End If



        rtn = UpdateLog(am, "startup.validate", "Testing webservices connection by logging in", 0)
        rtn = WSLogin(Host)
        BUValidate.Visible = False
        If rtn <> "OK" Then
            rtn = UpdateLog(am, "startup.validate", "login failed check your settings and ensure you have rights in client auto", 1)
            LBCAvalidation.Text = "Validation Failed"
            CredValidated = False
        Else
            rtn = UpdateLog(am, "startup.validate", "log in OK", 0)
            LBCAvalidation.Text = "Credentials Validated"
            CredValidated = True
            If checkEM.Checked = True Then
                rtn = UpdateLog(am, "startup.validate", "Save credentials is enabled saving now", 0)
                My.Settings.CAdomain = tbdomain.Text
                My.Settings.CAhost = TBHost.Text
                My.Settings.CApassword = tbpassword.Text
                My.Settings.CAuser = tbemuser.Text
                If CheckBoxLocal.Checked = True Then
                    My.Settings.UseLocal = "True"
                Else
                    My.Settings.UseLocal = "False"

                End If
                My.Settings.Save()

            End If
            GBM.Visible = False
            Lbvalidated.Text = "Connection validated to Client Auto Server"
            Lbvalidated1.Text = Host
            Lbvalidated.Visible = True
            burevalidate.Visible = True
            Lbvalidated1.Visible = True
            LBAllSoftware.Visible = True

            am = 1
            LogCreate(am)
            rtn = UpdateLog(am, "startup.validate", "Getting list of All Software", 0)
            Dim RTN1 As String = WSGetAllSoftware()
            If RTN1 <> "OK" Then
                rtn = UpdateLog(am, "startup.validate", "Getting List of all software failed", 2)
                LBAllSoftware.Text = "Failed to get list of All software"
            Else
                LBAllSoftware.Text = "Choose the software package to deliver"
                CBAllSoftware.AutoCompleteSource = AutoCompleteSource.ListItems
                CBAllSoftware.AutoCompleteMode = AutoCompleteMode.Suggest
                Dim j As Integer
                For j = 0 To TotalPackageCount
                    CBAllSoftware.Items.Add(Suggestions(j))

                Next
                CBAllSoftware.Sorted = True
                LBAllSoftware.Text = "Start Typing the name of the software package to be delivered"
                CBAllSoftware.Visible = True


            End If
            RTN1 = ""
            LBMachineList.Visible = True
            ListBoxMachine.Visible = True
            RTN1 = WSGetAllComputers()
            If RTN1 <> "OK" Then
                rtn = UpdateLog(am, "startup.validate", "Getting List of all computers failed", 2)
                LBMachineList.Text = "Failed to get list of All Machines"
            Else
                LBMachineList.Text = "Choose 0 to many machines to target"
                For j = 0 To TotalMachineCount
                    ListBoxMachine.Items.Add(ComputerNameList(j))

                Next
                ListBoxMachine.Sorted = True


            End If

            RTN1 = ""
            LBGroup.Visible = True
            ListBoxGroup.Visible = True
            RTN1 = WSGetAllGroups()
            If RTN1 <> "OK" Then
                rtn = UpdateLog(am, "startup.validate", "Getting List of all groups failed", 2)
                LBMachineList.Text = "Failed to get list of All groups"
            Else
                LBGroup.Text = "Choose 0 to many groups to target"
                For j = 0 To TotalGroupCount - 1
                    ListBoxGroup.Items.Add(GroupNameList(j))

                Next
                ListBoxGroup.Sorted = True


            End If
        End If

    End Sub


    Private Sub BUvalidate_Click(sender As Object, e As EventArgs) Handles BUValidate.Click
        If CredValidated = False Then
            LBCAvalidation.Text = "Evaluating Client Auto Credentials"
            ManagerValidate()
        End If
    End Sub



    Private Sub BUexit_Click(sender As Object, e As EventArgs) Handles BUexit.Click
        Exitapp()
    End Sub

    Private Sub CheckEM_CheckedChanged(sender As Object, e As EventArgs) Handles checkEM.CheckedChanged

        If checkEM.Checked = False Then
            My.Settings.CAdomain = vbNullString
            My.Settings.CAhost = vbNullString
            My.Settings.CApassword = vbNullString
            My.Settings.CAuser = vbNullString
            My.Settings.UseLocal = vbNullString
            My.Settings.Save()

        Else
            If CredValidated = True Then

                My.Settings.CAdomain = tbdomain.Text
                My.Settings.CAhost = TBHost.Text
                My.Settings.CApassword = tbpassword.Text
                My.Settings.CAuser = tbemuser.Text
                If My.Settings.UseLocal = "True" Then
                    Uselocal = True
                    CheckBoxLocal.Checked = True
                Else
                    Uselocal = False
                    CheckBoxLocal.Checked = False
                End If
                My.Settings.Save()

            End If
        End If
    End Sub


    Private Sub CBAllSoftware_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBAllSoftware.SelectedIndexChanged
        If CBAllSoftware.SelectedIndex >= 0 Then
            Dim rtn As String
            SelectedPackageName = Strings.Left(CBAllSoftware.SelectedItem, InStr(CBAllSoftware.SelectedItem, "'") - 1)
            Dim j As Integer
            GBpackageSelected.Visible = True
            buPackageAnother.Visible = True
            For j = 0 To TotalPackageCount
                If SelectedPackageName = PackageNameList(j) Then

                    SelectedPackageVersion = PackageVersionList(j)
                    SelectedPackageUUID = PackageUUIDList(j)
                    TBSelectedPackage.Text = SelectedPackageName
                    TbselectedVersion.Text = SelectedPackageVersion
                    SelectedPackageversionTmp = SelectedPackageVersion.Replace("/", "_")
                    SelectedPackageNameTmp = SelectedPackageName.Replace("/", "_")
                    SelectedPackageversionTmp = SelectedPackageversionTmp.Replace(":", "_")
                    SelectedPackageNameTmp = SelectedPackageNameTmp.Replace(":", "_")


                    Exit For
                End If

            Next j
            LBAllSoftware.Visible = False
            CBAllSoftware.Visible = False
            rtn = ActivateProcedure()


        End If


    End Sub

    Private Sub CBAllSoftware_DropDown(sender As Object, e As EventArgs) Handles CBAllSoftware.DropDown
        GBpackageSelected.Visible = False
    End Sub





    Private Sub BUAnother_Click(sender As Object, e As EventArgs) Handles buPackageAnother.Click

        ResetPackage()
        LbProcedure.Visible = False
        CBProcedure.Visible = False
    End Sub

    Private Sub Burevalidate_Click(sender As Object, e As EventArgs) Handles burevalidate.Click
        burevalidate.Visible = False
        Lbvalidated.Visible = False
        Lbvalidated1.Visible = False
        Bukeep.Visible = True
        BUValidate.Visible = False
        GBM.Visible = True
    End Sub

    Private Sub Bukeep_Click(sender As Object, e As EventArgs) Handles Bukeep.Click
        GBM.Visible = False
        burevalidate.Visible = True
        Lbvalidated.Visible = True
        Lbvalidated1.Visible = True
    End Sub




    Private Sub CheckBoxLocal_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxLocal.CheckedChanged
        If CredValidated = True Then
            GBM.Visible = False
            burevalidate.Visible = True
            Lbvalidated.Visible = True
        End If
        If CheckBoxLocal.Checked = True Then
            tbdomain.Visible = False
            TBCAdomain.Visible = False
            Uselocal = True
        Else
            tbdomain.Visible = True
            TBCAdomain.Visible = True
            Uselocal = False
        End If
    End Sub



    Public Sub New()
        InitializeComponent()

    End Sub




    Private Sub GBEM_Enter(sender As Object, e As EventArgs) Handles GBM.Enter

    End Sub

    Function ActivateProcedure() As String
        UpdateLog(5, "startup.ActivteProcedure", "UUID for package selected is " + SelectedPackageUUID, 0)
        Dim rtn As String
        LbProcedure.Visible = True
        CBProcedure.Visible = True
        UpdateLog(5, "startup.ActivteProcedure", "Getting list of package prcedures ", 0)
        rtn = WSGetPackageProceures()
        If rtn <> "OK" Then
            UpdateLog(5, "startup.ActivteProcedure", "Getting list of package failed ", 2)
            Return "NOT OK"
            Exit Function
        End If
        For j = 0 To TotalProcedureCount - 1
            CBProcedure.Items.Add(ProcedureNameList(j))
        Next
        CBProcedure.Sorted = True
        BUProcedureAnother.Visible = True
        Return "OK"
    End Function

    Function ResetPackage() As String
        ResetContainer()
        ResetProcedure()
        SelectedPackageName = Nothing
        SelectedPackageUUID = Nothing
        SelectedPackageVersion = Nothing
        CBAllSoftware.SelectedIndex = -1
        GBpackageSelected.Visible = False
        LBAllSoftware.Visible = True
        CBAllSoftware.Visible = True
        buPackageAnother.Visible = False
        LBAllSoftware.Text = "Start Typing the name of the software package to be delivered"
        CBProcedure.Items.Clear()
        Return "OK"
    End Function


    Function ResetProcedure() As String
        ResetContainer()
        GBProcedures.Visible = False
        LbProcedure.Visible = True
        CBProcedure.Visible = True
        CBProcedure.SelectedIndex = -1
        SelectedProcedureName = Nothing
        SelectedProcedureUUID = Nothing
        Return "OK"
    End Function

    Function ResetContainer() As String
        GBContainer.Visible = False
        ContainerReadyCheck()
        BUCreateContainer.Visible = False
        tbcontainer.Text = Nothing
        Return "OK"
    End Function

    Function ContainerReadyCheck() As String
        Dim targetOK As Boolean = False
        Dim procok As Boolean = False
        If SelectedProcedureUUID <> Nothing Then
            targetOK = True
            lbProcedureSelected.Visible = False
        Else
            lbProcedureSelected.Visible = True
        End If
        If (ListBoxGroup.SelectedIndex >= 0 OrElse ListBoxMachine.SelectedIndex >= 0) Then
            procok = True
            LBTargetSelected.Visible = False
        Else
            LBTargetSelected.Visible = True
        End If
        If targetOK = True AndAlso procok = True Then
            GBContainer.Visible = True
        Else
            GBContainer.Visible = False
        End If

        Return "OK"
    End Function

    Private Sub CBProcedure_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBProcedure.SelectedIndexChanged
        If CBProcedure.SelectedIndex >= 0 Then
            SelectedProcedureName = CBProcedure.SelectedItem
            For j = 0 To TotalProcedureCount
                If SelectedProcedureName = ProcedureNameList(j) Then
                    SelectedProcedureUUID = ProcedureUUIDList(j)
                    Exit For
                End If
            Next
            GBProcedures.Visible = True
            TBProcedureSelected.Text = SelectedProcedureName
            GBProcedures.Visible = True
            LbProcedure.Visible = False
            CBProcedure.Visible = False
        End If
        ContainerReadyCheck()
    End Sub

    Private Sub BUProcedureAnother_Click(sender As Object, e As EventArgs) Handles BUProcedureAnother.Click
        ResetProcedure()
        ContainerReadyCheck()
    End Sub

    Private Sub ListBoxMachine_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBoxMachine.SelectedIndexChanged
        If ListBoxMachine.SelectedIndex = -1 Then
            BuClearMachine.Visible = False
        Else
            BuClearMachine.Visible = True
        End If

        ContainerReadyCheck()

    End Sub

    Private Sub ListBoxGroup_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBoxGroup.SelectedIndexChanged
        If ListBoxGroup.SelectedIndex = -1 Then
            BuCleargroup.Visible = False
        Else
            BuCleargroup.Visible = True
        End If
        ContainerReadyCheck()
    End Sub

    Private Sub BuClearMachine_Click(sender As Object, e As EventArgs) Handles BuClearMachine.Click
        ListBoxMachine.SelectedIndex = -1
        ContainerReadyCheck()

    End Sub

    Private Sub BuCleargroup_Click(sender As Object, e As EventArgs) Handles BuCleargroup.Click
        ListBoxGroup.SelectedIndex = -1
        ContainerReadyCheck()
    End Sub

    Private Sub Tbcontainer_TextChanged(sender As Object, e As EventArgs) Handles tbcontainer.TextChanged
        If tbcontainer.Text = Nothing Then
            BUCreateContainer.Visible = False
        Else
            BUCreateContainer.Visible = True
        End If
    End Sub

    Private Sub BUCreateContainer_Click(sender As Object, e As EventArgs) Handles BUCreateContainer.Click
        LockChanges()
        Dim rtn As String
        Dim MachineArrayLen As Long
        Dim GroupArraylen As Long


        If ListBoxMachine.SelectedItems.Count = 0 Then
            MachineArrayLen = -1

        Else
            MachineArrayLen = ListBoxMachine.SelectedItems.Count - 1
        End If
        ReDim MachineArray(MachineArrayLen)
        If (ListBoxMachine.SelectedItems.Count <> 0) Then

            'MachineArray(0) = Nothing

            'Else

            For j = 0 To ListBoxMachine.SelectedItems.Count - 1
                rtn = GetUUID(ListBoxMachine.SelectedItems(j), "Machine")


                If rtn = "NotOK" Then
                    MessageBox.Show("unable to find the uud for the machine name this should never happen")
                Else
                    MachineArray(j) = rtn
                End If
            Next

        End If

        If ListBoxGroup.SelectedItems.Count = 0 Then
            GroupArraylen = 0

        Else
            GroupArraylen = ListBoxGroup.SelectedItems.Count - 1
        End If
        ReDim GroupArray(GroupArraylen)




        If ListBoxGroup.SelectedItems.Count <> 0 Then
            'GroupArray(0) = ChrW(&H0)
            'Else
            For j = 0 To ListBoxGroup.SelectedItems.Count - 1
                rtn = GetUUID(ListBoxGroup.SelectedItems(j), "Group")

                If rtn = "NOTOK" Then
                    MessageBox.Show("unable to find the uud for the group name this should never happen")
                Else
                    GroupArray(j) = rtn
                End If
            Next
        Else
            GroupArray(0) = WSGetAllComputerUUID()
        End If
        rtn = WSCreateContainer(tbcontainer.Text)
        If rtn = "NOTOK" Then
            MessageBox.Show("creating container failed")
            Exit Sub
        End If


        rtn = WSCreateSoftwareJob("myTest")
        If rtn = "NOTOK" Then
            MessageBox.Show("creating Software Job Failed")
            Exit Sub
        End If

        rtn = WSSealAndActivate()
        If rtn = "NOTOK" Then
            MessageBox.Show("sealing Software Container Failed")
            Exit Sub
        End If
    End Sub

    Function GetUUID(name As String, mg As String) As String
        If mg = "Machine" Then
            Dim topcount As Long = TotalMachineCount - 1
            For j = 0 To topcount
                If name = ComputerNameList(j) Then
                    Return ComputerUUIDList(j)
                    Exit Function
                End If
            Next

        Else
            Dim topcount As Long = TotalGroupCount - 1
            For j = 0 To topcount
                If name = GroupNameList(j) Then
                    Return GroupUUIDList(j)
                    Exit Function
                End If
            Next




        End If
        Return "NotOK"
        Exit Function

    End Function


    Function LockChanges() As String
        buPackageAnother.Visible = False
        BUProcedureAnother.Visible = False
        BUCreateContainer.Visible = False
        BuClearMachine.Visible = False
        BuCleargroup.Visible = False
        'ListBoxMachine.SelectionMode = SelectionMode.None
        ' ListBoxGroup.SelectionMode = SelectionMode.None

        LBMachineList.Text = "changes locked"
        LBGroup.Text = "changes locked"
        Return "OK"
    End Function


End Class


