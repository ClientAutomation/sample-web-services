﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Startup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GBM = New System.Windows.Forms.GroupBox()
        Me.TBHost = New System.Windows.Forms.TextBox()
        Me.CheckBoxLocal = New System.Windows.Forms.CheckBox()
        Me.Bukeep = New System.Windows.Forms.Button()
        Me.checkEM = New System.Windows.Forms.CheckBox()
        Me.LBCAvalidation = New System.Windows.Forms.Label()
        Me.tbpassword = New System.Windows.Forms.TextBox()
        Me.tbemuser = New System.Windows.Forms.TextBox()
        Me.BUValidate = New System.Windows.Forms.Button()
        Me.tbdomain = New System.Windows.Forms.TextBox()
        Me.TBCAPassword = New System.Windows.Forms.Label()
        Me.TBCAUser = New System.Windows.Forms.Label()
        Me.TBCAdomain = New System.Windows.Forms.Label()
        Me.LBHost = New System.Windows.Forms.Label()
        Me.BUexit = New System.Windows.Forms.Button()
        Me.LBAllSoftware = New System.Windows.Forms.Label()
        Me.CBAllSoftware = New System.Windows.Forms.ComboBox()
        Me.GBpackageSelected = New System.Windows.Forms.GroupBox()
        Me.buPackageAnother = New System.Windows.Forms.Button()
        Me.TbselectedVersion = New System.Windows.Forms.TextBox()
        Me.TBSelectedPackage = New System.Windows.Forms.TextBox()
        Me.Lbversion = New System.Windows.Forms.Label()
        Me.Lbpackselectlabel = New System.Windows.Forms.Label()
        Me.Lbvalidated = New System.Windows.Forms.Label()
        Me.burevalidate = New System.Windows.Forms.Button()
        Me.Lbvalidated1 = New System.Windows.Forms.Label()
        Me.LbProcedure = New System.Windows.Forms.Label()
        Me.CBProcedure = New System.Windows.Forms.ComboBox()
        Me.LBMachineList = New System.Windows.Forms.Label()
        Me.ListBoxMachine = New System.Windows.Forms.ListBox()
        Me.BUCreateContainer = New System.Windows.Forms.Button()
        Me.GBContainer = New System.Windows.Forms.GroupBox()
        Me.BUContainerAbort = New System.Windows.Forms.Button()
        Me.BUContainerExecute = New System.Windows.Forms.Button()
        Me.tbcontainer = New System.Windows.Forms.TextBox()
        Me.LBContainer = New System.Windows.Forms.Label()
        Me.LBGroup = New System.Windows.Forms.Label()
        Me.ListBoxGroup = New System.Windows.Forms.ListBox()
        Me.GBProcedures = New System.Windows.Forms.GroupBox()
        Me.TBProcedureSelected = New System.Windows.Forms.TextBox()
        Me.LBProcedureName = New System.Windows.Forms.Label()
        Me.BUProcedureAnother = New System.Windows.Forms.Button()
        Me.lbProcedureSelected = New System.Windows.Forms.Label()
        Me.LBTargetSelected = New System.Windows.Forms.Label()
        Me.BuClearMachine = New System.Windows.Forms.Button()
        Me.BuCleargroup = New System.Windows.Forms.Button()
        Me.GBM.SuspendLayout()
        Me.GBpackageSelected.SuspendLayout()
        Me.GBContainer.SuspendLayout()
        Me.GBProcedures.SuspendLayout()
        Me.SuspendLayout()
        '
        'GBM
        '
        Me.GBM.Controls.Add(Me.TBHost)
        Me.GBM.Controls.Add(Me.CheckBoxLocal)
        Me.GBM.Controls.Add(Me.Bukeep)
        Me.GBM.Controls.Add(Me.checkEM)
        Me.GBM.Controls.Add(Me.LBCAvalidation)
        Me.GBM.Controls.Add(Me.tbpassword)
        Me.GBM.Controls.Add(Me.tbemuser)
        Me.GBM.Controls.Add(Me.BUValidate)
        Me.GBM.Controls.Add(Me.tbdomain)
        Me.GBM.Controls.Add(Me.TBCAPassword)
        Me.GBM.Controls.Add(Me.TBCAUser)
        Me.GBM.Controls.Add(Me.TBCAdomain)
        Me.GBM.Controls.Add(Me.LBHost)
        Me.GBM.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GBM.Location = New System.Drawing.Point(24, 59)
        Me.GBM.Name = "GBM"
        Me.GBM.Size = New System.Drawing.Size(438, 228)
        Me.GBM.TabIndex = 0
        Me.GBM.TabStop = False
        Me.GBM.Text = "Client Auto Enterprise Credentials"
        '
        'TBHost
        '
        Me.TBHost.Location = New System.Drawing.Point(178, 17)
        Me.TBHost.Name = "TBHost"
        Me.TBHost.Size = New System.Drawing.Size(237, 20)
        Me.TBHost.TabIndex = 12
        '
        'CheckBoxLocal
        '
        Me.CheckBoxLocal.AutoSize = True
        Me.CheckBoxLocal.Location = New System.Drawing.Point(178, 124)
        Me.CheckBoxLocal.Name = "CheckBoxLocal"
        Me.CheckBoxLocal.Size = New System.Drawing.Size(150, 17)
        Me.CheckBoxLocal.TabIndex = 11
        Me.CheckBoxLocal.Text = "Use Local Credentials"
        Me.CheckBoxLocal.UseVisualStyleBackColor = True
        '
        'Bukeep
        '
        Me.Bukeep.Location = New System.Drawing.Point(209, 168)
        Me.Bukeep.Name = "Bukeep"
        Me.Bukeep.Size = New System.Drawing.Size(93, 48)
        Me.Bukeep.TabIndex = 10
        Me.Bukeep.Text = "Keep Current Credentials"
        Me.Bukeep.UseVisualStyleBackColor = True
        Me.Bukeep.Visible = False
        '
        'checkEM
        '
        Me.checkEM.AutoSize = True
        Me.checkEM.Location = New System.Drawing.Point(178, 148)
        Me.checkEM.Name = "checkEM"
        Me.checkEM.Size = New System.Drawing.Size(105, 17)
        Me.checkEM.TabIndex = 9
        Me.checkEM.Text = "Save Settings"
        Me.checkEM.UseVisualStyleBackColor = True
        '
        'LBCAvalidation
        '
        Me.LBCAvalidation.AutoSize = True
        Me.LBCAvalidation.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBCAvalidation.Location = New System.Drawing.Point(19, 168)
        Me.LBCAvalidation.Name = "LBCAvalidation"
        Me.LBCAvalidation.Size = New System.Drawing.Size(184, 13)
        Me.LBCAvalidation.TabIndex = 8
        Me.LBCAvalidation.Text = "Client Auto Credentials Not Evaluated"
        '
        'tbpassword
        '
        Me.tbpassword.Location = New System.Drawing.Point(178, 72)
        Me.tbpassword.Name = "tbpassword"
        Me.tbpassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.tbpassword.Size = New System.Drawing.Size(237, 20)
        Me.tbpassword.TabIndex = 7
        '
        'tbemuser
        '
        Me.tbemuser.Location = New System.Drawing.Point(178, 46)
        Me.tbemuser.Name = "tbemuser"
        Me.tbemuser.Size = New System.Drawing.Size(237, 20)
        Me.tbemuser.TabIndex = 6
        '
        'BUValidate
        '
        Me.BUValidate.Location = New System.Drawing.Point(308, 168)
        Me.BUValidate.Name = "BUValidate"
        Me.BUValidate.Size = New System.Drawing.Size(93, 48)
        Me.BUValidate.TabIndex = 2
        Me.BUValidate.Text = "Validate Credentials"
        Me.BUValidate.UseVisualStyleBackColor = True
        Me.BUValidate.Visible = False
        '
        'tbdomain
        '
        Me.tbdomain.Location = New System.Drawing.Point(178, 98)
        Me.tbdomain.Name = "tbdomain"
        Me.tbdomain.Size = New System.Drawing.Size(237, 20)
        Me.tbdomain.TabIndex = 5
        '
        'TBCAPassword
        '
        Me.TBCAPassword.AutoSize = True
        Me.TBCAPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBCAPassword.Location = New System.Drawing.Point(19, 75)
        Me.TBCAPassword.Name = "TBCAPassword"
        Me.TBCAPassword.Size = New System.Drawing.Size(82, 13)
        Me.TBCAPassword.TabIndex = 3
        Me.TBCAPassword.Text = "Login Password"
        '
        'TBCAUser
        '
        Me.TBCAUser.AutoSize = True
        Me.TBCAUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBCAUser.Location = New System.Drawing.Point(19, 49)
        Me.TBCAUser.Name = "TBCAUser"
        Me.TBCAUser.Size = New System.Drawing.Size(58, 13)
        Me.TBCAUser.TabIndex = 2
        Me.TBCAUser.Text = "Login User"
        '
        'TBCAdomain
        '
        Me.TBCAdomain.AutoSize = True
        Me.TBCAdomain.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBCAdomain.Location = New System.Drawing.Point(19, 101)
        Me.TBCAdomain.Name = "TBCAdomain"
        Me.TBCAdomain.Size = New System.Drawing.Size(103, 13)
        Me.TBCAdomain.TabIndex = 1
        Me.TBCAdomain.Text = "Login Domain Name"
        '
        'LBHost
        '
        Me.LBHost.AutoSize = True
        Me.LBHost.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBHost.Location = New System.Drawing.Point(7, 20)
        Me.LBHost.Name = "LBHost"
        Me.LBHost.Size = New System.Drawing.Size(114, 13)
        Me.LBHost.TabIndex = 0
        Me.LBHost.Text = "Client Auto Host Name"
        '
        'BUexit
        '
        Me.BUexit.Location = New System.Drawing.Point(803, 607)
        Me.BUexit.Name = "BUexit"
        Me.BUexit.Size = New System.Drawing.Size(93, 48)
        Me.BUexit.TabIndex = 3
        Me.BUexit.Text = "EXIT"
        Me.BUexit.UseVisualStyleBackColor = True
        '
        'LBAllSoftware
        '
        Me.LBAllSoftware.AutoSize = True
        Me.LBAllSoftware.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBAllSoftware.Location = New System.Drawing.Point(483, 49)
        Me.LBAllSoftware.Name = "LBAllSoftware"
        Me.LBAllSoftware.Size = New System.Drawing.Size(168, 13)
        Me.LBAllSoftware.TabIndex = 10
        Me.LBAllSoftware.Text = "Getting List of Software Packages"
        Me.LBAllSoftware.Visible = False
        '
        'CBAllSoftware
        '
        Me.CBAllSoftware.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.CBAllSoftware.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.CBAllSoftware.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CBAllSoftware.FormattingEnabled = True
        Me.CBAllSoftware.Location = New System.Drawing.Point(486, 65)
        Me.CBAllSoftware.Name = "CBAllSoftware"
        Me.CBAllSoftware.Size = New System.Drawing.Size(400, 21)
        Me.CBAllSoftware.TabIndex = 11
        Me.CBAllSoftware.Visible = False
        '
        'GBpackageSelected
        '
        Me.GBpackageSelected.Controls.Add(Me.buPackageAnother)
        Me.GBpackageSelected.Controls.Add(Me.TbselectedVersion)
        Me.GBpackageSelected.Controls.Add(Me.TBSelectedPackage)
        Me.GBpackageSelected.Controls.Add(Me.Lbversion)
        Me.GBpackageSelected.Controls.Add(Me.Lbpackselectlabel)
        Me.GBpackageSelected.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GBpackageSelected.Location = New System.Drawing.Point(486, 96)
        Me.GBpackageSelected.Name = "GBpackageSelected"
        Me.GBpackageSelected.Size = New System.Drawing.Size(400, 152)
        Me.GBpackageSelected.TabIndex = 12
        Me.GBpackageSelected.TabStop = False
        Me.GBpackageSelected.Text = "Package Selected"
        Me.GBpackageSelected.Visible = False
        '
        'buPackageAnother
        '
        Me.buPackageAnother.Location = New System.Drawing.Point(271, 99)
        Me.buPackageAnother.Name = "buPackageAnother"
        Me.buPackageAnother.Size = New System.Drawing.Size(93, 38)
        Me.buPackageAnother.TabIndex = 15
        Me.buPackageAnother.Text = "Select Another"
        Me.buPackageAnother.UseVisualStyleBackColor = True
        Me.buPackageAnother.Visible = False
        '
        'TbselectedVersion
        '
        Me.TbselectedVersion.Location = New System.Drawing.Point(15, 73)
        Me.TbselectedVersion.Name = "TbselectedVersion"
        Me.TbselectedVersion.ReadOnly = True
        Me.TbselectedVersion.Size = New System.Drawing.Size(152, 20)
        Me.TbselectedVersion.TabIndex = 9
        '
        'TBSelectedPackage
        '
        Me.TBSelectedPackage.Location = New System.Drawing.Point(15, 29)
        Me.TBSelectedPackage.Name = "TBSelectedPackage"
        Me.TBSelectedPackage.ReadOnly = True
        Me.TBSelectedPackage.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.TBSelectedPackage.Size = New System.Drawing.Size(351, 20)
        Me.TBSelectedPackage.TabIndex = 8
        Me.TBSelectedPackage.WordWrap = False
        '
        'Lbversion
        '
        Me.Lbversion.AutoSize = True
        Me.Lbversion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbversion.Location = New System.Drawing.Point(17, 57)
        Me.Lbversion.Name = "Lbversion"
        Me.Lbversion.Size = New System.Drawing.Size(42, 13)
        Me.Lbversion.TabIndex = 3
        Me.Lbversion.Text = "Version"
        '
        'Lbpackselectlabel
        '
        Me.Lbpackselectlabel.AutoSize = True
        Me.Lbpackselectlabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbpackselectlabel.Location = New System.Drawing.Point(17, 18)
        Me.Lbpackselectlabel.Name = "Lbpackselectlabel"
        Me.Lbpackselectlabel.Size = New System.Drawing.Size(35, 13)
        Me.Lbpackselectlabel.TabIndex = 2
        Me.Lbpackselectlabel.Text = "Name"
        '
        'Lbvalidated
        '
        Me.Lbvalidated.AutoSize = True
        Me.Lbvalidated.Cursor = System.Windows.Forms.Cursors.Cross
        Me.Lbvalidated.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbvalidated.Location = New System.Drawing.Point(31, 13)
        Me.Lbvalidated.Name = "Lbvalidated"
        Me.Lbvalidated.Size = New System.Drawing.Size(218, 13)
        Me.Lbvalidated.TabIndex = 13
        Me.Lbvalidated.Text = "Connection validated to Client Auto Manager"
        Me.Lbvalidated.Visible = False
        '
        'burevalidate
        '
        Me.burevalidate.Location = New System.Drawing.Point(367, 13)
        Me.burevalidate.Name = "burevalidate"
        Me.burevalidate.Size = New System.Drawing.Size(84, 43)
        Me.burevalidate.TabIndex = 14
        Me.burevalidate.Text = "Enter New Credentials"
        Me.burevalidate.UseVisualStyleBackColor = True
        Me.burevalidate.Visible = False
        '
        'Lbvalidated1
        '
        Me.Lbvalidated1.AutoSize = True
        Me.Lbvalidated1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbvalidated1.Location = New System.Drawing.Point(31, 28)
        Me.Lbvalidated1.Name = "Lbvalidated1"
        Me.Lbvalidated1.Size = New System.Drawing.Size(0, 13)
        Me.Lbvalidated1.TabIndex = 15
        Me.Lbvalidated1.Visible = False
        '
        'LbProcedure
        '
        Me.LbProcedure.AutoSize = True
        Me.LbProcedure.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LbProcedure.Location = New System.Drawing.Point(506, 262)
        Me.LbProcedure.Name = "LbProcedure"
        Me.LbProcedure.Size = New System.Drawing.Size(180, 13)
        Me.LbProcedure.TabIndex = 17
        Me.LbProcedure.Text = "Getting List of Software Proceedures"
        Me.LbProcedure.Visible = False
        '
        'CBProcedure
        '
        Me.CBProcedure.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append
        Me.CBProcedure.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.CBProcedure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CBProcedure.FormattingEnabled = True
        Me.CBProcedure.Location = New System.Drawing.Point(501, 278)
        Me.CBProcedure.Name = "CBProcedure"
        Me.CBProcedure.Size = New System.Drawing.Size(387, 21)
        Me.CBProcedure.TabIndex = 18
        Me.CBProcedure.Visible = False
        '
        'LBMachineList
        '
        Me.LBMachineList.AutoSize = True
        Me.LBMachineList.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBMachineList.Location = New System.Drawing.Point(12, 308)
        Me.LBMachineList.Name = "LBMachineList"
        Me.LBMachineList.Size = New System.Drawing.Size(121, 13)
        Me.LBMachineList.TabIndex = 19
        Me.LBMachineList.Text = "Getting List of Machines"
        Me.LBMachineList.Visible = False
        '
        'ListBoxMachine
        '
        Me.ListBoxMachine.FormattingEnabled = True
        Me.ListBoxMachine.Location = New System.Drawing.Point(15, 331)
        Me.ListBoxMachine.Name = "ListBoxMachine"
        Me.ListBoxMachine.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBoxMachine.Size = New System.Drawing.Size(174, 355)
        Me.ListBoxMachine.Sorted = True
        Me.ListBoxMachine.TabIndex = 23
        '
        'BUCreateContainer
        '
        Me.BUCreateContainer.Location = New System.Drawing.Point(213, 55)
        Me.BUCreateContainer.Name = "BUCreateContainer"
        Me.BUCreateContainer.Size = New System.Drawing.Size(110, 38)
        Me.BUCreateContainer.TabIndex = 24
        Me.BUCreateContainer.Text = "CreateContainer"
        Me.BUCreateContainer.UseVisualStyleBackColor = True
        Me.BUCreateContainer.Visible = False
        '
        'GBContainer
        '
        Me.GBContainer.Controls.Add(Me.BUCreateContainer)
        Me.GBContainer.Controls.Add(Me.BUContainerAbort)
        Me.GBContainer.Controls.Add(Me.BUContainerExecute)
        Me.GBContainer.Controls.Add(Me.tbcontainer)
        Me.GBContainer.Controls.Add(Me.LBContainer)
        Me.GBContainer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GBContainer.Location = New System.Drawing.Point(489, 483)
        Me.GBContainer.Name = "GBContainer"
        Me.GBContainer.Size = New System.Drawing.Size(332, 119)
        Me.GBContainer.TabIndex = 25
        Me.GBContainer.TabStop = False
        Me.GBContainer.Text = "Container Info"
        Me.GBContainer.Visible = False
        '
        'BUContainerAbort
        '
        Me.BUContainerAbort.Location = New System.Drawing.Point(15, 55)
        Me.BUContainerAbort.Name = "BUContainerAbort"
        Me.BUContainerAbort.Size = New System.Drawing.Size(93, 38)
        Me.BUContainerAbort.TabIndex = 15
        Me.BUContainerAbort.Text = "Abort"
        Me.BUContainerAbort.UseVisualStyleBackColor = True
        Me.BUContainerAbort.Visible = False
        '
        'BUContainerExecute
        '
        Me.BUContainerExecute.Location = New System.Drawing.Point(114, 55)
        Me.BUContainerExecute.Name = "BUContainerExecute"
        Me.BUContainerExecute.Size = New System.Drawing.Size(93, 38)
        Me.BUContainerExecute.TabIndex = 14
        Me.BUContainerExecute.Text = "Execute"
        Me.BUContainerExecute.UseVisualStyleBackColor = True
        Me.BUContainerExecute.Visible = False
        '
        'tbcontainer
        '
        Me.tbcontainer.BackColor = System.Drawing.SystemColors.Window
        Me.tbcontainer.Location = New System.Drawing.Point(15, 29)
        Me.tbcontainer.Name = "tbcontainer"
        Me.tbcontainer.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.tbcontainer.Size = New System.Drawing.Size(293, 20)
        Me.tbcontainer.TabIndex = 8
        Me.tbcontainer.WordWrap = False
        '
        'LBContainer
        '
        Me.LBContainer.AutoSize = True
        Me.LBContainer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBContainer.Location = New System.Drawing.Point(17, 15)
        Me.LBContainer.Name = "LBContainer"
        Me.LBContainer.Size = New System.Drawing.Size(83, 13)
        Me.LBContainer.TabIndex = 2
        Me.LBContainer.Text = "Container Name"
        '
        'LBGroup
        '
        Me.LBGroup.AutoSize = True
        Me.LBGroup.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBGroup.Location = New System.Drawing.Point(220, 308)
        Me.LBGroup.Name = "LBGroup"
        Me.LBGroup.Size = New System.Drawing.Size(121, 13)
        Me.LBGroup.TabIndex = 26
        Me.LBGroup.Text = "Getting List of Machines"
        Me.LBGroup.Visible = False
        '
        'ListBoxGroup
        '
        Me.ListBoxGroup.FormattingEnabled = True
        Me.ListBoxGroup.Location = New System.Drawing.Point(223, 331)
        Me.ListBoxGroup.Name = "ListBoxGroup"
        Me.ListBoxGroup.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ListBoxGroup.Size = New System.Drawing.Size(174, 355)
        Me.ListBoxGroup.Sorted = True
        Me.ListBoxGroup.TabIndex = 27
        '
        'GBProcedures
        '
        Me.GBProcedures.Controls.Add(Me.TBProcedureSelected)
        Me.GBProcedures.Controls.Add(Me.LBProcedureName)
        Me.GBProcedures.Controls.Add(Me.BUProcedureAnother)
        Me.GBProcedures.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GBProcedures.Location = New System.Drawing.Point(487, 308)
        Me.GBProcedures.Name = "GBProcedures"
        Me.GBProcedures.Size = New System.Drawing.Size(399, 126)
        Me.GBProcedures.TabIndex = 28
        Me.GBProcedures.TabStop = False
        Me.GBProcedures.Text = "Procedures"
        Me.GBProcedures.Visible = False
        '
        'TBProcedureSelected
        '
        Me.TBProcedureSelected.Location = New System.Drawing.Point(12, 46)
        Me.TBProcedureSelected.Name = "TBProcedureSelected"
        Me.TBProcedureSelected.ReadOnly = True
        Me.TBProcedureSelected.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.TBProcedureSelected.Size = New System.Drawing.Size(351, 20)
        Me.TBProcedureSelected.TabIndex = 8
        Me.TBProcedureSelected.WordWrap = False
        '
        'LBProcedureName
        '
        Me.LBProcedureName.AutoSize = True
        Me.LBProcedureName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBProcedureName.Location = New System.Drawing.Point(13, 27)
        Me.LBProcedureName.Name = "LBProcedureName"
        Me.LBProcedureName.Size = New System.Drawing.Size(101, 13)
        Me.LBProcedureName.TabIndex = 2
        Me.LBProcedureName.Text = "Procedure Selected"
        '
        'BUProcedureAnother
        '
        Me.BUProcedureAnother.Location = New System.Drawing.Point(272, 76)
        Me.BUProcedureAnother.Name = "BUProcedureAnother"
        Me.BUProcedureAnother.Size = New System.Drawing.Size(93, 38)
        Me.BUProcedureAnother.TabIndex = 15
        Me.BUProcedureAnother.Text = "Select Another"
        Me.BUProcedureAnother.UseVisualStyleBackColor = True
        Me.BUProcedureAnother.Visible = False
        '
        'lbProcedureSelected
        '
        Me.lbProcedureSelected.AutoSize = True
        Me.lbProcedureSelected.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbProcedureSelected.Location = New System.Drawing.Point(506, 448)
        Me.lbProcedureSelected.Name = "lbProcedureSelected"
        Me.lbProcedureSelected.Size = New System.Drawing.Size(197, 20)
        Me.lbProcedureSelected.TabIndex = 29
        Me.lbProcedureSelected.Text = "NO Procedure Selected"
        '
        'LBTargetSelected
        '
        Me.LBTargetSelected.AutoSize = True
        Me.LBTargetSelected.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBTargetSelected.Location = New System.Drawing.Point(720, 448)
        Me.LBTargetSelected.Name = "LBTargetSelected"
        Me.LBTargetSelected.Size = New System.Drawing.Size(167, 20)
        Me.LBTargetSelected.TabIndex = 30
        Me.LBTargetSelected.Text = "NO Target Selected"
        '
        'BuClearMachine
        '
        Me.BuClearMachine.Location = New System.Drawing.Point(15, 692)
        Me.BuClearMachine.Name = "BuClearMachine"
        Me.BuClearMachine.Size = New System.Drawing.Size(174, 21)
        Me.BuClearMachine.TabIndex = 31
        Me.BuClearMachine.Text = "Clear Selection"
        Me.BuClearMachine.UseVisualStyleBackColor = True
        Me.BuClearMachine.Visible = False
        '
        'BuCleargroup
        '
        Me.BuCleargroup.Location = New System.Drawing.Point(223, 692)
        Me.BuCleargroup.Name = "BuCleargroup"
        Me.BuCleargroup.Size = New System.Drawing.Size(174, 21)
        Me.BuCleargroup.TabIndex = 32
        Me.BuCleargroup.Text = "ClearSelection"
        Me.BuCleargroup.UseVisualStyleBackColor = True
        Me.BuCleargroup.Visible = False
        '
        'Startup
        '
        Me.ClientSize = New System.Drawing.Size(934, 965)
        Me.ControlBox = False
        Me.Controls.Add(Me.BuCleargroup)
        Me.Controls.Add(Me.BuClearMachine)
        Me.Controls.Add(Me.LBTargetSelected)
        Me.Controls.Add(Me.lbProcedureSelected)
        Me.Controls.Add(Me.GBContainer)
        Me.Controls.Add(Me.ListBoxGroup)
        Me.Controls.Add(Me.LBGroup)
        Me.Controls.Add(Me.CBProcedure)
        Me.Controls.Add(Me.ListBoxMachine)
        Me.Controls.Add(Me.LbProcedure)
        Me.Controls.Add(Me.LBMachineList)
        Me.Controls.Add(Me.Lbvalidated1)
        Me.Controls.Add(Me.burevalidate)
        Me.Controls.Add(Me.Lbvalidated)
        Me.Controls.Add(Me.GBpackageSelected)
        Me.Controls.Add(Me.CBAllSoftware)
        Me.Controls.Add(Me.LBAllSoftware)
        Me.Controls.Add(Me.BUexit)
        Me.Controls.Add(Me.GBM)
        Me.Controls.Add(Me.GBProcedures)
        Me.MaximizeBox = False
        Me.Name = "Startup"
        Me.ShowIcon = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.GBM.ResumeLayout(False)
        Me.GBM.PerformLayout()
        Me.GBpackageSelected.ResumeLayout(False)
        Me.GBpackageSelected.PerformLayout()
        Me.GBContainer.ResumeLayout(False)
        Me.GBContainer.PerformLayout()
        Me.GBProcedures.ResumeLayout(False)
        Me.GBProcedures.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GBM As GroupBox
    Friend WithEvents tbpassword As TextBox
    Friend WithEvents tbemuser As TextBox
    Friend WithEvents tbdomain As TextBox
    Friend WithEvents TBCAPassword As Label
    Friend WithEvents TBCAUser As Label
    Friend WithEvents TBCAdomain As Label
    Friend WithEvents LBHost As Label
    Friend WithEvents BUValidate As Button
    Friend WithEvents BUexit As Button
    Friend WithEvents LBCAvalidation As Label
    Friend WithEvents LBAllSoftware As Label
    Friend WithEvents CBAllSoftware As ComboBox
    Friend WithEvents checkEM As CheckBox
    Friend WithEvents GBpackageSelected As GroupBox
    Friend WithEvents TbselectedVersion As TextBox
    Friend WithEvents TBSelectedPackage As TextBox
    Friend WithEvents Lbversion As Label
    Friend WithEvents Lbpackselectlabel As Label
    Friend WithEvents buPackageAnother As Button
    Friend WithEvents Lbvalidated As Label
    Friend WithEvents burevalidate As Button
    Friend WithEvents Bukeep As Button
    Friend WithEvents Lbvalidated1 As Label
    Friend WithEvents CheckBoxLocal As CheckBox
    Friend WithEvents TBHost As TextBox
    Friend WithEvents LbProcedure As Label
    Friend WithEvents CBProcedure As ComboBox
    Friend WithEvents LBMachineList As Label
    Friend WithEvents ListBoxMachine As ListBox
    Friend WithEvents BUCreateContainer As Button
    Friend WithEvents GBContainer As GroupBox
    Friend WithEvents BUContainerAbort As Button
    Friend WithEvents BUContainerExecute As Button
    Friend WithEvents tbcontainer As TextBox
    Friend WithEvents LBContainer As Label
    Friend WithEvents LBGroup As Label
    Friend WithEvents ListBoxGroup As ListBox
    Friend WithEvents GBProcedures As GroupBox
    Friend WithEvents TBProcedureSelected As TextBox
    Friend WithEvents LBProcedureName As Label
    Friend WithEvents BUProcedureAnother As Button
    Friend WithEvents lbProcedureSelected As Label
    Friend WithEvents LBTargetSelected As Label
    Friend WithEvents BuClearMachine As Button
    Friend WithEvents BuCleargroup As Button
End Class
